#!/usr/bin/env bash
# Install jq and rlwrap from bundled .deb files
cd "$(dirname "$0")"
sudo dpkg -i libonig5_*.deb libjq1_*.deb jq_*.deb rlwrap_*.deb
echo ""
echo "Installed:"
jq --version 2>/dev/null && echo "  jq: OK" || echo "  jq: FAILED"
command -v rlwrap &>/dev/null && echo "  rlwrap: OK" || echo "  rlwrap: FAILED"
