#NOTE
This version of PowerUp is now unsupported.

Go to https://github.com/Veil-Framework/PowerTools/tree/master/PowerUp
for the most current version.
